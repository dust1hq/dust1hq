from Crypto.Cipher import AES
from base64 import b64decode
from base64 import b64encode

BLOCK_SIZE = 16  # Bytes
pad = lambda s: s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * \
                chr(BLOCK_SIZE - len(s) % BLOCK_SIZE)
unpad = lambda s: s[:-ord(s[len(s) - 1:])]

def expand_key(key_3_bytes):
    key_16_bytes = bytes()
    for i in range(16):
        key_16_bytes += key_3_bytes[i%3:i%3+1]        
    return key_16_bytes


def encryption(message, key1, key2):
    message = pad(message)
    cipher1 = AES.new(expand_key(key1), AES.MODE_ECB)
    cipher2 = AES.new(expand_key(key2), AES.MODE_ECB)
    cipher_text = cipher2.encrypt(cipher1.encrypt(message.encode('utf-8')))
    return b64encode(cipher_text)


def decryption(cipher_text, key1, key2):
    cipher_text = b64decode(cipher_text)
    cipher1 = AES.new(expand_key(key1), AES.MODE_ECB) 
    cipher2 = AES.new(expand_key(key2), AES.MODE_ECB)
    original_message = cipher1.decrypt(cipher2.decrypt(cipher_text))
    return unpad(original_message).decode('utf-8')